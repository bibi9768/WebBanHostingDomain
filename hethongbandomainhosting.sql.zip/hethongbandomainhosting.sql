-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1:3306
-- Thời gian đã tạo: Th6 27, 2020 lúc 11:56 AM
-- Phiên bản máy phục vụ: 8.0.18
-- Phiên bản PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `hethongbandomainhosting`
--
CREATE DATABASE IF NOT EXISTS `hethongbandomainhosting` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `hethongbandomainhosting`;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chitiethosting`
--

DROP TABLE IF EXISTS `chitiethosting`;
CREATE TABLE IF NOT EXISTS `chitiethosting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idhosting` int(11) NOT NULL,
  `sothang` int(11) NOT NULL,
  `gia` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `chitiethosting`
--

INSERT INTO `chitiethosting` (`id`, `idhosting`, `sothang`, `gia`) VALUES
(1, 1, 6, 169200),
(2, 1, 12, 327600),
(3, 1, 24, 633600),
(4, 1, 36, 918000),
(5, 2, 3, 145500),
(6, 2, 6, 282000),
(7, 2, 12, 546000),
(8, 2, 24, 1056000),
(9, 2, 36, 1530000),
(10, 3, 3, 276450),
(11, 3, 6, 535800),
(12, 3, 12, 1037400),
(13, 3, 24, 2006400),
(14, 3, 36, 2907000),
(15, 4, 1, 150000),
(16, 4, 3, 436500),
(17, 4, 6, 846000),
(18, 4, 12, 1638000),
(19, 4, 24, 3168000),
(20, 4, 36, 4590000),
(21, 5, 1, 350000),
(22, 5, 3, 1018500),
(23, 5, 6, 1974000),
(24, 5, 12, 3822000),
(25, 5, 24, 7392000),
(26, 5, 36, 10710000),
(27, 6, 6, 169200),
(28, 6, 12, 327600),
(29, 6, 24, 633600),
(30, 6, 36, 918000),
(31, 7, 3, 145500),
(32, 7, 6, 282000),
(33, 7, 12, 546000),
(34, 7, 24, 1056000),
(35, 7, 36, 1530000),
(36, 8, 3, 276450),
(37, 8, 6, 535800),
(38, 8, 12, 1037400),
(39, 8, 24, 2006400),
(40, 8, 36, 2907000),
(41, 9, 1, 150000),
(42, 9, 3, 436500),
(43, 9, 6, 3168000),
(44, 9, 12, 1638000),
(45, 9, 24, 3168000),
(46, 9, 36, 4590000),
(47, 10, 1, 350000),
(48, 10, 3, 1018500),
(49, 10, 6, 1674000),
(50, 10, 12, 3822000),
(51, 10, 24, 7392000),
(52, 10, 36, 10710000),
(53, 11, 1, 180000),
(54, 11, 3, 523800),
(55, 11, 6, 1015200),
(56, 11, 12, 1965600),
(57, 11, 24, 3801600),
(58, 11, 36, 5508000),
(59, 12, 1, 300000),
(60, 12, 3, 837000),
(61, 12, 6, 1692000),
(62, 12, 12, 3276000),
(63, 12, 24, 6336000),
(64, 12, 36, 9180000),
(65, 13, 1, 500000),
(66, 13, 3, 1455000),
(67, 13, 6, 2820000),
(68, 13, 12, 5460000),
(69, 13, 24, 10560000),
(70, 13, 36, 15300000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `domain`
--

DROP TABLE IF EXISTS `domain`;
CREATE TABLE IF NOT EXISTS `domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phidangkynamdau` int(255) DEFAULT NULL,
  `phiduytrimoinam` int(255) NOT NULL,
  `loai` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `domain`
--

INSERT INTO `domain` (`id`, `domain`, `phidangkynamdau`, `phiduytrimoinam`, `loai`) VALUES
(1, '.com', 309000, 309000, 1),
(2, '.net', 309000, 309000, 1),
(3, '.org', 338000, 338000, 1),
(4, '.biz', 375000, 375000, 1),
(5, '.me', 710000, 710000, 1),
(6, '.mobi', 499000, 499000, 1),
(7, '.name', 330000, 330000, 1),
(8, '.ws', 620000, 620000, 1),
(9, '.co', 740000, 740000, 0),
(10, '.cc', 499000, 499000, 0),
(11, '.tv', 880000, 880000, 0),
(12, '.xxx', 2500000, 2500000, 0),
(13, '.pro', 396000, 396000, 0),
(14, '.pw', 560000, 560000, 0),
(15, '.us', 264000, 264000, 1),
(16, '.ca', 374000, 374000, 0),
(17, '.bz', 600000, 600000, 0),
(18, '.asia', 359000, 359000, 1),
(19, '.in', 340000, 340000, 0),
(20, '.eu', 300000, 300000, 1),
(21, '.fr', 550000, 550000, 0),
(22, '.de', 264000, 264000, 0),
(23, '.media', 800000, 800000, 0),
(24, '.photography', 535000, 535000, 0),
(25, '.news', 590000, 590000, 0),
(26, '.land', 760000, 760000, 0),
(27, '.xyz', 280000, 280000, 0),
(28, '.tips', 499000, 499000, 0),
(29, '.top', 360000, 360000, 0),
(30, '.uk', 215000, 215000, 1),
(31, '.link', 250000, 250000, 0),
(32, '.site', 690000, 690000, 0),
(33, '.club', 300000, 300000, 0),
(34, '.online', 870000, 870000, 0),
(35, '.website', 470000, 470000, 0),
(36, '.men', 715000, 715000, 0),
(37, '.space', 499000, 499000, 0),
(38, '.io', 1800000, 1800000, 0),
(39, '.fun', 550000, 550000, 0),
(40, '.trade', 700000, 700000, 0),
(41, '.host', 1955000, 1955000, 0),
(42, '.best', 499000, 499000, 0),
(43, '.press', 1700000, 1700000, 0),
(44, '.gift', 699000, 699000, 0),
(45, '.zone', 775000, 775000, 0),
(46, '.es', 264000, 264000, 0),
(47, '.tech', 1220000, 1220000, 0),
(48, '.company', 480000, 480000, 0),
(49, '.info', 366000, 366000, 1),
(50, '.art', 328000, 328000, 0),
(51, '.studio', 540000, 540000, 0),
(52, '.vn', 700000, 418181, 2),
(53, '.name.vn', 74545, 47272, 2),
(54, '.co.in', 200000, 200000, 0),
(55, '.vip', 366000, 377000, 0),
(56, '.email', 550000, 550000, 0),
(57, '.store', 1200000, 1200000, 0),
(58, '.design', 1283000, 1283000, 0),
(59, '.party', 740000, 740000, 0),
(60, '.live', 650000, 650000, 0),
(61, '.pet', 430000, 430000, 0),
(62, '.pink', 430000, 430000, 0),
(63, '.red', 430000, 430000, 0),
(64, '.school', 770000, 770000, 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hoadondomain`
--

DROP TABLE IF EXISTS `hoadondomain`;
CREATE TABLE IF NOT EXISTS `hoadondomain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idnguoidung` int(11) NOT NULL,
  `hoten` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diachi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sodienthoai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gia` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ngaytao` timestamp NOT NULL,
  `phuongthucthanhtoan` int(11) NOT NULL DEFAULT '0',
  `trangthaiduyet` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `hoadondomain`
--

INSERT INTO `hoadondomain` (`id`, `idnguoidung`, `hoten`, `diachi`, `sodienthoai`, `name`, `domain`, `gia`, `ngaytao`, `phuongthucthanhtoan`, `trangthaiduyet`) VALUES
(1, 1, 'pn', 'Thủ Dầu Một', '03467104040', 'thien123', '.com', '309000', '2020-04-12 18:40:18', 0, 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hoadonhosting`
--

DROP TABLE IF EXISTS `hoadonhosting`;
CREATE TABLE IF NOT EXISTS `hoadonhosting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idnguoidung` int(11) NOT NULL,
  `idgoidichvu` int(11) NOT NULL,
  `ngaymua` date NOT NULL,
  `ngaykichhoat` date NOT NULL,
  `ngayhethan` date NOT NULL,
  `trangthaiduyet` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hosting`
--

DROP TABLE IF EXISTS `hosting`;
CREATE TABLE IF NOT EXISTS `hosting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loaihosting` int(11) NOT NULL,
  `tengoi` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `giabatdautu` int(11) NOT NULL,
  `dungluong` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bangthong` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phanmemquantri` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `an` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `hosting`
--

INSERT INTO `hosting` (`id`, `loaihosting`, `tengoi`, `giabatdautu`, `dungluong`, `bangthong`, `website`, `phanmemquantri`, `an`) VALUES
(1, 1, 'LITE', 27300, '500 MB', '10 GB', '01', 'cPanel', 0),
(2, 1, 'BASIC', 45500, '01 GB', '25 GB', '02', 'cPanel', 0),
(3, 1, 'ENHANCED', 86450, '02 GB', '50 GB', '03', 'cPanel', 0),
(4, 1, 'PREMIUM', 136500, '03 GB', '200 GB', '06', 'cPanel', 0),
(5, 1, 'BUSINESS', 318500, '10 GB', 'KGH GB', '08', 'cPanel', 0),
(6, 2, 'W-LITE', 27300, '500 MB', '10 GB', '01', 'Plesk', 0),
(7, 2, 'W-BASIC', 45500, '01 GB', '25 GB', '02', 'Plesk', 0),
(8, 2, 'W-ENHANCED', 86450, '02 GB', '50 GB', '03', 'Plesk', 0),
(9, 2, 'W-PREMIUM', 136500, '03 GB', '200 GB', '06', 'Plesk', 0),
(10, 2, 'W-ADVANCED', 318500, '10 GB', 'KGH', '08', 'Plesk', 0),
(11, 3, 'WPH-I', 163800, '05 GB', 'Không giới hạn', '04', 'cPanel', 0),
(12, 3, 'WPH-II', 273000, '10 GB', 'Không giới hạn', '06', 'cPanel', 0),
(13, 3, 'WPH-III', 455000, '15 GB', 'Không giới hạn', '11', 'cPanel', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loaihosting`
--

DROP TABLE IF EXISTS `loaihosting`;
CREATE TABLE IF NOT EXISTS `loaihosting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `giabatdau` int(11) NOT NULL,
  `tenloai` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `oluutru` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phuhopmanguon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phienbanmanguon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phanmemquantri` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `hedieuhanh` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `webserver` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `an` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `loaihosting`
--

INSERT INTO `loaihosting` (`id`, `giabatdau`, `tenloai`, `oluutru`, `phuhopmanguon`, `phienbanmanguon`, `phanmemquantri`, `hedieuhanh`, `webserver`, `an`) VALUES
(1, 27250, 'HOSTING LINUX', '<span class=\"cl-orange\"> HDD</span>', 'Phù hợp mã nguồn <b><span class=\"cl-blue\"> PHP/MySQL</span></b>', '</i> Phiên bản PHP <b><span class=\"cl-blue\"> 5.3 - 7.0</span></b>', 'cPanel', 'Cloud Linux 6.x', 'LiteSpeed', 0),
(2, 27278, 'HOSTING WINDOWS', '<span class=\"cl-orange\"> HDD</span>', 'Phù hợp mã nguồn <b><span class=\"cl-blue\"> ASP/ASP.NET</span></b>', 'Phiên bản .NET <b><span class=\"cl-blue\"> 4.6.1</span></b>', 'Plesk', 'Windows Server 2012', 'IIS', 0),
(3, 163800, 'HOSTING WORDPRESS', '<span class=\"label-save\"> SSD</span>', 'Dành riêng <b><span class=\"cl-blue\"> cho WordPress</span></b>', 'Phiên bản .PHP <b><span class=\"cl-blue\"> 5.3 - 7.0</span></b>', 'cPanel', 'Cloud Linux 7.x', 'LiteSpeed', 0),
(4, 454090, 'RESELLER SSD', 'Ổ lưu trữ <b><span class=\"label-save\"> SSD</span></b>', 'Phù hợp mã nguồn <b><span class=\"cl-blue\"> PHP/MySQL</span></b>', '5.3 - 7.0', 'cPanel', 'Cloud Linux 7.x', 'LiteSpeed', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `magiamgia`
--

DROP TABLE IF EXISTS `magiamgia`;
CREATE TABLE IF NOT EXISTS `magiamgia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ma` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loaiduocgiam` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trigia` int(250) NOT NULL,
  `thoihan` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `magiamgia`
--

INSERT INTO `magiamgia` (`id`, `ma`, `loaiduocgiam`, `trigia`, `thoihan`) VALUES
(1, 'domain2020', 'domain', 20, '2020-06-29 17:00:00');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hoten` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sodienthoai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diachi` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `laquantri` tinyint(1) NOT NULL DEFAULT '0',
  `ngaydangky` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `hoten`, `email`, `password`, `sodienthoai`, `diachi`, `laquantri`) VALUES
(1, 'pn', 'bibi9768@gmail.com', '$2y$10$JC/jbNsXmUCCxNDFt82EXOgdgeAsoHHZ0DVUBQiZKEhNroqyA/RmK', '03467104040', 'Thủ Dầu Một', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
